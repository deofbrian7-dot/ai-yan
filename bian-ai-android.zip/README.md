# BIAN AI Android

Aplikasi Android berbasis Capacitor. Tidak membutuhkan backend sendiri.
Pengguna memasukkan OpenRouter API Key dari menu Pengaturan; key disimpan di localStorage perangkat.

## Build
```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK debug: `android/app/build/outputs/apk/debug/app-debug.apk`

Catatan keamanan: tanpa backend, API key yang digunakan di perangkat tidak dapat dirahasiakan sepenuhnya dari pemilik perangkat. Jangan memasukkan key rahasia organisasi/shared.
