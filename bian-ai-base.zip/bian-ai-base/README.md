# BIAN AI — Starter Base

Starter project BIAN AI dengan UI dark premium, backend Express, OpenRouter, SQLite, dan Docker.

## Jalankan lokal

1. Install Node.js 20 atau lebih baru.
2. `npm install`
3. Salin `.env.example` menjadi `.env`.
4. Isi `OPENROUTER_API_KEY` dengan key milikmu dari dashboard OpenRouter.
5. `npm start`
6. Buka `http://localhost:3000`.

## Deploy Pterodactyl

- Buat server Node.js/Docker yang menyediakan Node.js 20+.
- Upload repository atau clone GitHub.
- Install dependencies: `npm install --omit=dev`.
- Atur startup command: `npm start`.
- Atur environment variables di panel: `PORT` (gunakan port yang dialokasikan panel), `OPENROUTER_API_KEY`, `AI_MODEL`, `AI_MODELS`, `APP_URL`, dan `DB_PATH`.
- Pastikan direktori data persisten/ter-mount agar database tidak hilang saat reinstall.
- Arahkan reverse proxy dan HTTPS domain ke port server.

## GitHub

```bash
git init
git add .
git commit -m "Initial BIAN AI base"
git branch -M main
git remote add origin https://github.com/USERNAME/REPOSITORY.git
git push -u origin main
```

## API

- `GET /api/health` — status backend.
- `GET /api/models` — daftar model dari `AI_MODELS`.
- `POST /api/chat` — body `{ "messages": [{"role":"user","content":"Halo"}], "model":"openrouter/auto" }`.
- `GET /api/conversations` — daftar percakapan tersimpan.
- `POST /api/conversations` — simpan percakapan.
- `GET /api/conversations/:id` — baca percakapan.

## Keamanan penting

- Jangan pernah commit `.env`, API key, token, atau kredensial ke GitHub.
- Jangan memasukkan provider key ke JavaScript frontend atau APK. Simpan hanya sebagai environment variable backend.
- Ganti `APP_URL` dengan domain HTTPS milikmu.
- Tambahkan autentikasi pengguna sebelum membuka endpoint chat untuk publik. Starter ini belum menyediakan login, role admin, billing, atau otorisasi kepemilikan percakapan.
- OpenRouter dan model yang dipilih dapat mengenakan biaya; `openrouter/auto` tidak menjamin penggunaan gratis atau unlimited.
