require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const path = require('path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const db = new Database(process.env.DB_PATH || './data/bian-ai.sqlite');
require('fs').mkdirSync(path.dirname(path.resolve(process.env.DB_PATH || './data/bian-ai.sqlite')), { recursive: true });
db.exec(`CREATE TABLE IF NOT EXISTS conversations (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, messages TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '1mb' }));
app.use('/api/', rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'BIAN AI', provider: process.env.OPENROUTER_API_KEY ? 'configured' : 'missing_api_key' }));

app.get('/api/models', (_req, res) => {
  const models = (process.env.AI_MODELS || 'openrouter/auto').split(',').map(x => x.trim()).filter(Boolean);
  res.json({ models, default: process.env.AI_MODEL || models[0] });
});

app.post('/api/chat', async (req, res) => {
  try {
    const key = process.env.OPENROUTER_API_KEY;
    if (!key) return res.status(503).json({ error: 'API key belum dipasang di environment server.' });
    const { messages, model } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40) {
      return res.status(400).json({ error: 'Format messages tidak valid (maksimal 40 pesan).' });
    }
    const safeMessages = messages.map(m => {
      if (!m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') throw new Error('Pesan tidak valid.');
      return { role: m.role, content: m.content.slice(0, 12000) };
    });
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.APP_URL || `http://localhost:${PORT}`,
        'X-Title': 'BIAN AI'
      },
      body: JSON.stringify({
        model: typeof model === 'string' && model.trim() ? model.trim() : (process.env.AI_MODEL || 'openrouter/auto'),
        messages: [{ role: 'system', content: process.env.SYSTEM_PROMPT || 'Kamu adalah BIAN AI, asisten yang ramah, akurat, dan membantu. Jawab dalam bahasa pengguna.' }, ...safeMessages],
        temperature: 0.7
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data?.error?.message || 'Provider AI gagal memproses permintaan.' });
    const answer = data?.choices?.[0]?.message?.content;
    if (!answer) return res.status(502).json({ error: 'Provider tidak mengembalikan jawaban.' });
    res.json({ answer, model: data.model || model || process.env.AI_MODEL || 'openrouter/auto', usage: data.usage || null });
  } catch (err) {
    res.status(400).json({ error: err.message || 'Terjadi kesalahan server.' });
  }
});

app.post('/api/conversations', (req, res) => {
  const { title, messages } = req.body || {};
  if (!Array.isArray(messages)) return res.status(400).json({ error: 'messages harus berupa array.' });
  const result = db.prepare('INSERT INTO conversations (title, messages) VALUES (?, ?)').run(String(title || 'Percakapan baru').slice(0, 100), JSON.stringify(messages).slice(0, 200000));
  res.status(201).json({ id: result.lastInsertRowid });
});
app.get('/api/conversations', (_req, res) => {
  const rows = db.prepare('SELECT id, title, created_at FROM conversations ORDER BY id DESC LIMIT 50').all();
  res.json(rows);
});
app.get('/api/conversations/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM conversations WHERE id = ?').get(Number(req.params.id));
  if (!row) return res.status(404).json({ error: 'Percakapan tidak ditemukan.' });
  res.json({ ...row, messages: JSON.parse(row.messages) });
});

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.listen(PORT, '0.0.0.0', () => console.log(`BIAN AI running on port ${PORT}`));
